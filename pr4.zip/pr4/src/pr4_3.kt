import kotlin.random.Random

fun main() {
    println("Введите исходное сообщение:")
    val message = readLine()!!.toUpperCase().filter { it.isLetter() }

    println("Введите ключ:")
    val key = readLine()!!.toUpperCase().filter { it.isLetter() }

    println("Использовать типовую таблицу? (да/нет):")
    val useStandardTable = readLine()!!.toLowerCase() == "да"

    val table = if (useStandardTable) generateStandardTable() else generateRandomTable()

    val extendedKey = extendKey(key, message.length)
    val encryptedMessage = encrypt(message, extendedKey, table)

    printResults(message, extendedKey, encryptedMessage, table)
}

// Генерация стандартной таблицы
fun generateStandardTable(): Array<String> {
    val alphabet = ('А'..'Я').toList() + listOf('Ё')
    return Array(33) { i ->
        alphabet.subList(i, alphabet.size) + alphabet.subList(0, i)
    }.map { it.joinToString("") }.toTypedArray()
}

// Генерация случайной таблицы
fun generateRandomTable(): Array<String> {
    val alphabet = ('А'..'Я').toList() + listOf('Ё')
    val shuffledAlphabet = alphabet.shuffled(Random(System.currentTimeMillis()))

    // Вращаем shuffledAlphabet в нужном количестве раз
    return Array(33) { i ->
        val rotatedAlphabet = shuffledAlphabet.toMutableList()
        rotate(rotatedAlphabet, i) // Вращаем на i позиций
        rotatedAlphabet.joinToString("")
    }
}

// Функция для вращения списка на заданное количество позиций
fun rotate(list: MutableList<Char>, positions: Int) {
    repeat(positions) {
        list.add(list.removeAt(0))  // Перемещаем первый элемент в конец списка
    }
}

// Расширение ключа до нужной длины
fun extendKey(key: String, length: Int): String {
    return (key.repeat(length / key.length + 1)).substring(0, length)
}

// Функция шифрования
fun encrypt(message: String, key: String, table: Array<String>): String {
    val encrypted = StringBuilder()

    // Индексы символов в таблице
    for (i in message.indices) {
        val row = key[i] - 'А' // Индекс строки (ключ)
        val col = message[i] - 'А' // Индекс столбца (сообщение)
        encrypted.append(table[row][col])
    }

    return encrypted.toString()
}

// Вывод результатов
fun printResults(message: String, key: String, encryptedMessage: String, table: Array<String>) {
    println("\nИсходное сообщение: $message")
    println("Ключ: $key")
    println("Зашифрованное сообщение: $encryptedMessage")

    println("\nШифровальная таблица:")
    for (row in table) {
        println(row)
    }
}
